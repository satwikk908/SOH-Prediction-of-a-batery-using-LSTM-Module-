# Battery Voltage Prediction using LSTM

This project trains a Long Short-Term Memory (LSTM) neural network to perform time-series prediction of battery Voltage using a dataset collected at 25 degrees Celsius.

The notebook handles data loading, preprocessing, model definition, training, and evaluation, with an emphasis on using Google Colab with GPU acceleration for faster training. A separate comparison notebook was run to evaluate other model architectures.

## 1. Project Overview

* Goal: Predict the "Voltage" of a battery over time.
* Model Type: Recurrent Neural Network (LSTM) for time-series forecasting.
* Target Data: Battery data collected at 25°C (path: /content/drive/MyDrive/LSTM/batry_lstm/data/25degC).

## 2. Model and Configuration

The primary model is a two-layer LSTM with the following configuration:

| Parameter | Value | Details |
| :--- | :--- | :--- |
| Input Features (X) | ["Voltage", "Current", "Temperature", "Capacity", "WhAccu"] | The full set of features used for prediction. |
| Target Variable (y)| "Voltage" | The single feature the model is trained to predict. |
| Look-back Window| N_TIMESTEPS = 30 | The number of previous time steps (data points) used to predict the next step. |
| Epochs | N_EPOCHS = 10 | The number of training cycles. |
| Batch Size | BATCH_SIZE = 32 | |
| Training Ratio | TRAIN_RATIO = 0.8 | 80% of the data is used for training, 20% for testing. |

### Model Architecture

The Keras Sequential model architecture consists of:

* Layer 1: LSTM (50 units, return_sequences=True) with Dropout(0.2).
* Layer 2: LSTM (50 units, return_sequences=False) with Dropout(0.2).
* Output Layer: Dense (1 unit).
* Optimization: optimizer='adam', loss='mean_squared_error'.

## 3. Data and Preprocessing

The notebook includes robust data handling to prepare the raw CSV files for the LSTM model:

1. Loading: All CSV files within the defined DATA_PATH are loaded and combined. The script successfully loaded 36 files and resulted in a combined shape of (1045195, 5) data points.
2. Cleaning: The code specifically addresses three issues:
    * Skips the unit row after the header (skiprows=[1]).
    * Strips all whitespace from column headers.
    * Converts selected columns (INPUT_FEATURES) to numeric types, coercing errors.
3. Missing Values: Any missing (NaN) values in the input features are imputed using the mean of that column.
4. Scaling: The combined data is scaled using MinMaxScaler to a range of (0, 1).
5. Sequencing: The scaled data is transformed into time sequences of length N_TIMESTEPS (30) for the LSTM input.

## 4. Results and Model Files

### Evaluation Metrics

The initial execution of the LSTM model reported a low Root Mean Squared Error (RMSE) on the test set:

* LSTM RMSE (Test Set, Voltage): 0.0105

### Model Comparison Summary

A subsequent notebook comparing this LSTM model with other architectures yielded the following scaled RMSE and Mean Absolute Error (MAE) values in percentage form:

| Model | RMSE (%) | MAE (%) | Best Performer |
| :--- | :--- | :--- | :--- |
| LSTM | 1.28% | 0.96% | |
| GRU | 0.79% | 0.59% |  |
| CNN | 24.79% | 18.59% | |

The GRU model showed the lowest error in the comparison, suggesting it may be a more accurate choice for this prediction task.

### Saved Model Files

The following trained model files were either saved by the project or provided:

| Filename | Description |
| :--- | :--- |
| colab_lstm_30step_10epoch.keras | The model trained within the main notebook. Saved to /content/drive/MyDrive/LSTM/batry_lstm/models. |
| local_cpu_lstm_model_final.keras | A Keras model file (likely the final LSTM version). |
| cpu_lstm_model.keras | A Keras model file (likely an earlier version). |

## 5. Execution Instructions

The project is designed to run in a Google Colab environment.

1. Mount Google Drive: Ensure your Google Drive is mounted to allow the script to access the data and save the model:
    ```python
    from google.colab import drive
    drive.mount('/content/drive')
    ```
2. Run run_lstm_training(): Execute the main function defined in the notebook to load data, build, train, and save the LSTM model.
    ```python
    run_lstm_training()
    ```
    *Note: The script includes an automatic GPU check and memory growth setting to optimize training if a GPU is available*.
Would you like me to clarify any section of this README or extract a specific piece of information from the notebook?